<?php $__env->startSection('judul'); ?>
Form penerbit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form id="frmPenerbit" class="form-horizontal" action="<?php echo e(url('penerbit/save')); ?>" method="post" enctype="multipart/form-data">
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    <div class="row">
        <div class="fForm col-md-8">
            <div class="box">
                <!-- Bidodata Anggota -->
                <div class="box-header with-border">
                    <h3 class="box-title">Data Penerbit</h3>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <label for="penerbit" class="col-sm-2 control-label">Penerbit</label>
                        <div class="col-sm-10">
                            <input type="hidden" class="form-control" id="kd_penerbit" name="kd_penerbit" value="<?php echo e($penerbit['kd_penerbit']); ?>">
                            <input type="text" class="form-control" id="penerbit" placeholder="Nama Penerbit" name="penerbit" value="<?php echo e($penerbit['nama_penerbit']); ?>">
                        </div>
                    </div>
                </div>
                <!-- /.box-body -->
                <div class="box-footer">
                    <button type="submit" class="btn btn-primary pull-right">SAVE</button>
                </div>                   
            </div>
        </div>       
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>