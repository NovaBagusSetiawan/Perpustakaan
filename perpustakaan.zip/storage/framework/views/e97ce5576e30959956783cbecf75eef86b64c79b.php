<?php $__env->startSection('judul'); ?>
Form User
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form id="frmUser" class="form-horizontal" action="<?php echo e(url('user/save')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="fFoto col-md-3">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Foto</h3>
                </div>
                <div class="box-body">
                    <?php if($user['avatar']): ?>
                        <img id="avatar" src="<?php echo e(asset('img/'.$user['avatar'])); ?>" style="width:100%;border: 2px solid #ccc;">
                    <?php else: ?>
                        <img id="avatar" src="<?php echo e(asset('img/no-image.png')); ?>" style="width:100%;border: 2px solid #ccc;">
                    <?php endif; ?>
                    <input id="file" type="file" name="avatar" style="display: none">
                    <input type="hidden" name="old_avatar" value="<?php echo e($user['avatar']); ?>">
                </div>
            </div>
        </div>
        <div class="fForm col-md-9">
            <div class="box">
                <!-- Bidodata user -->
                <div class="box-header with-border">
                    <h3 class="box-title">Data user</h3>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <label for="nama" class="col-sm-2 control-label">Nama</label>
                        <div class="col-sm-10">
                            <input type="hidden" name="id" value="<?php echo e($user['id']); ?>">
                            <input type="text" class="form-control" id="nama" placeholder="Nama" name="name" value="<?php echo e($user['name']); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="alamat" class="col-sm-2 control-label">Alamat</label>
                        <div class="col-sm-10">
                            <textarea class="form-control" rows="3" placeholder="Alamat" name="alamat"><?php echo e($user['alamat']); ?></textarea>
                        </div>
                    </div>                      
                    <div class="form-group">
                        <label for="telp" class="col-sm-2 control-label">Telepon</label>
                        <div class="col-sm-10">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                                <input type="text" class="form-control" placeholder="Telepon" name="telp" value="<?php echo e($user['telp']); ?>"">
                            </div> 
                        </div>
                    </div> 
                    <div class="form-group">
                        <label for="email" class="col-sm-2 control-label">Email</label>
                        <div class="col-sm-10">
                            <div class="input-group">
                                <span class="input-group-addon">@</span>
                                <input type="email" class="form-control" placeholder="Email" name="email" value="<?php echo e($user['email']); ?>">
                            </div> 
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="password" class="col-sm-2 control-label">Password</label>
                        <div class="col-sm-10">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>             
                                <input type="password" class="form-control" id="password" placeholder="Password" name="password">
                                <input type="hidden" value="<?php echo e($user['password']); ?>" name="old_password">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="level" class="col-sm-2 control-label">Level</label>
                        <div class="col-sm-10">
                            <select class="form-control" name="level" value="<?php echo e($user['level']); ?>">
                                <option value="">- Pilih Level User -</option>
                                <option <?php echo e($user['level']==1 ? 'selected' : ''); ?> value="1">Admin</option>
                                <option <?php echo e($user['level']==2 ? 'selected' : ''); ?> value="2">Operator</option>
                            </select>
                        </div>
                    </div>                     
                </div>
                <!-- /.box-body -->
                <div class="box-footer">
                    <button type="submit" class="btn btn-primary pull-right">SAVE</button>
                </div>                   
            </div>
        </div>       
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>