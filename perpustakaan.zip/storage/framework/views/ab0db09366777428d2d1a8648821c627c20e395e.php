<?php $__env->startSection('judul'); ?>
Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ac-dash'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subjudul'); ?>
The future is not where my dream is
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-3 col-sm-6 col-xs-12">
    <div class="info-box bg-green">
      <span class="info-box-icon"><i class="fa fa-rocket"></i></span>

      <div class="info-box-content">
        <span class="info-box-text"><?php echo e($pinjam_banyak[0]->nama); ?></span>
        <span class="info-box-number"><?php echo e($pinjam_banyak[0]->jumlah); ?> Buku</span>
        <div class="progress">
          <div class="progress-bar" style="width:<?php echo e($pinjam_banyak[0]->jumlah); ?>%"></div>
        </div>
            <span class="progress-description">
            Terbanyak
            </span>
      </div>
      <!-- /.info-box-content -->
    </div> 
      <!-- /.info-box  -->
  </div> 

  <div class="col-md-3 col-sm-6 col-xs-12">
    <div class="info-box bg-purple">
      <span class="info-box-icon"><i class="fa fa-users"></i></span>

      <div class="info-box-content">
        <span class="info-box-text">Anggota</span>
        <span class="info-box-number"><?php echo e($anggota[0]->jumlah); ?> Anggota</span>

        <div class="progress">
          <div class="progress-bar" style="width: <?php echo e($anggota[0]->jumlah); ?>%"></div>
        </div>
            <span class="progress-description">
              Anggota Saat Ini
            </span>
      </div>
      <!-- /.info-box-content -->
    </div>
    <!-- /.info-box -->
  </div>

  <div class="col-md-3 col-sm-6 col-xs-12">
    <div class="info-box bg-yellow">
      <span class="info-box-icon"><i class="fa fa-tasks"></i></span>

      <div class="info-box-content">
        <span class="info-box-text">Jumlah Peminjam</span>
        <span class="info-box-number"><?php echo e($jmlh_pinjam[0]->jumlah); ?> <i class="fa fa-user"></i></span>

        <div class="progress">
          <div class="progress-bar" style="width: <?php echo e($jmlh_pinjam[0]->jumlah); ?>%"></div>
        </div>
            <span class="progress-description" id="bulan">
              
            </span>
      </div>
      <!-- /.info-box-content -->
    </div>
    <!-- /.info-box -->
  </div>

  <div class="col-md-3 col-sm-6 col-xs-12">
    <div class="info-box bg-blue">
      <span class="info-box-icon"><i class="fa fa-calendar"></i></span>

      <div class="info-box-content">
        <span class="info-box-text"><?php echo e($p_bulan[0]->nama); ?></span>
        <span class="info-box-number"><?php echo e($p_bulan[0]->jumlah); ?></span>

        <div class="progress">
          <div class="progress-bar" style="width: <?php echo e($p_bulan[0]->jumlah); ?>%"></div>
        </div>
            <span class="progress-description" >
              pinjam banyak/bulan
            </span>
      </div>
      <!-- /.info-box-content -->
    </div>
    <!-- /.info-box -->
  </div>

 <div class="box-header with-border">
              <h3 class="box-title">Latest Orders</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>

            <div class="box-body">
              <div class="table-responsive">
                <table class="table no-margin">
                  <thead>
                  <tr>
                    <th>Order ID</th>
                    <th>Item</th>
                    <th>Status</th>
                    
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td><a href="pages/examples/invoice.html">OR9842</a></td>
                    <td>Asus ROG Phone</td>
                    <td><span class="label label-success">Shipped</span></td>
                    
                  </tr>
                  <tr>
                    <td><a href="pages/examples/invoice.html">OR1848</a></td>
                    <td>Samsung Smart TV</td>
                    <td><span class="label label-warning">Pending</span></td>
                   
                  </tr>
                  <tr>
                    <td><a href="pages/examples/invoice.html">OR7429</a></td>
                    <td>iPhone 6 Plus</td>
                    <td><span class="label label-danger">Delivered</span></td>
                    
                  </tr>
                  <tr>
                    <td><a href="pages/examples/invoice.html">OR7429</a></td>
                    <td>Asus ROG GL553VD</td>
                    <td><span class="label label-info">Processing</span></td>
                   
                  </tr>
                  <tr>
                    <td><a href="pages/examples/invoice.html">OR1848</a></td>
                    <td>Vivo V11 Pro</td>
                    <td><span class="label label-warning">Pending</span></td>
                    
                  </tr>
                  <tr>
                    <td><a href="pages/examples/invoice.html">OR7429</a></td>
                    <td>iPhone XS</td>
                    <td><span class="label label-danger">Delivered</span></td>
                    
                  </tr>
                  <tr>
                    <td><a href="pages/examples/invoice.html">OR9842</a></td>
                    <td>PUBG</td>
                    <td><span class="label label-success">Shipped</span></td>
                    
                  </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.table-responsive -->
            
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>