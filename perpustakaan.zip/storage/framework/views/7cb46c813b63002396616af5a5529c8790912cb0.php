<?php $__env->startSection('judul'); ?>
Data Peminjam Yang Belum Mengembalikan Buku
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ac-pin'); ?>
active
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="box">
    <div class="box-header">
    <a href="<?php echo e(url('rpt/pinjam')); ?>" targen="blank"><button type="button" class="btn btn-success"><i class="fa fa-print" ></i> Print PDF</button></a>
    </div>
    <div class="box-body">
        <table id="data" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No Pinjam</th>
                    <th>Tanggal Buku Kembali</th>
                    <th>Judul</th>
                    <th>Nama Peminjam</th>
                </tr>
            </thead>
            <tbody>
                <!-- Menampilkan Data Pinjam -->
                <?php $__currentLoopData = $pinjam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsPin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($rsPin->no_pinjam); ?></td>
                    <td><?php echo e($rsPin->tgl_kembali); ?></td>   
                    <td><?php echo e($rsPin->judul); ?></td>
                    <td><?php echo e($rsPin->nama); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>