<?php $__env->startSection('judul'); ?>
Edit data
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- general form elements -->
    <div class="box box-primary">
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" method="post" action="">
            <div class="box-body">
                    <div class="form-group">
                        <label for="no_anggota">No anggota</label>
                        <input type="text" class="form-control" id="no_anggota" placeholder="No anggota">
                    </div>
                    <div class="form-group">
                        <label for="nama">Nama</label>
                        <input type="text" class="form-control" id="nama" placeholder="Nama">
                    </div>
                    <div class="form-group">
                        <label for="lahir">Lahir</label>
                        <input type="text" class="form-control" id="lahir" placeholder="tempat">
                        <input type="text" class="form-control" id="lahir" placeholder="tanggal">
                    </div>
            
                    <div class="form-group">
                        <label for="email">Email address</label>
                        <input type="email" class="form-control" id="email" placeholder="Enter email">
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" placeholder="Password">
                    </div>
                    <!-- <div class="form-group">
                        <label for="exampleInputFile">File input</label>
                        <input type="file" id="exampleInputFile">
                        <p class="help-block">Example block-level help text here.</p>
                    </div> -->
                <!-- <div class="checkbox">
                    <label>
                    <input type="checkbox"> Check me out
                    </label>
                </div> -->
                
                <!-- /.box-body -->

                <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
                </div>
        </form>
    </div>
    <!-- /.box -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>