
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(asset('img/yogs.jpg')); ?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo e(Auth::user()->name); ?></p>
          <!-- Status -->
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>

      <!-- search form (Optional) -->
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
          <span class="input-group-btn">
              <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
              </button>
            </span>
        </div>
      </form>
      <!-- /.search form -->

      <!-- Sidebar Menu -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">HEADER</li>
        <!-- Optionally, you can add icons to the links -->
        <li class="active"><a href="/dashboard"><i class="fa fa-home"></i> <span>Home</span></a></li>
        <li class="treeview">
          <a href="#"><i class="fa fa-book"></i> <span>Buku</span>
            <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
          </a>
          <ul class="treeview-menu">
            <li><a href='<?php echo e(url("buku")); ?>'>Data Buku</a></li>
            <li><a href="<?php echo e(url('buku/add')); ?>">Tambah Data Buku</a></li>
            <li><a href='<?php echo e(url("koleksi")); ?>'>Data Koleksi</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#"><i class="fa fa-user"></i> <span>Anggota</span>
            <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
          </a>
          <ul class="treeview-menu">
            <li><a href='<?php echo e(url("anggota")); ?>'>Data anggota</a></li>
            <li><a href="<?php echo e(url('anggota/add')); ?>">Tambah Data Anggota</a></li>
          </ul>
        </li>
        </li>
        <li class="treeview">
            <a href="#"><i class="fa fa-industry"></i> <span>Penerbit</span>
              <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
            </a>
            <ul class="treeview-menu">
            <li><a href='<?php echo e(url("penerbit")); ?>'>Data Penerbit</a></li>
            <li><a href='<?php echo e(url("penerbit/add")); ?>'>Tambah Penerbit</a></li>
            
          </ul>
        </li>
        <li class="treeview">
            <a href="#"><i class="fa fa-user"></i> <span>Pengarang</span>
              <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
            </a>
            <ul class="treeview-menu">
            <li><a href='<?php echo e(url("pengarang")); ?>'>Data Pengarang</a></li>
            <li><a href='<?php echo e(url("pengarang/add")); ?>'>Tambah Pengarang</a></li>
            
          </ul>
        </li>
        <li class="treeview">
            <a href="#"><i class="fa fa-tasks"></i> <span>Rak</span>
              <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
            </a>
            <ul class="treeview-menu">
            <li><a href='<?php echo e(url("rak")); ?>'>Data Rak</a></li>
            <li><a href='<?php echo e(url("rak/add")); ?>'>Tambah Rak</a></li>
            
          </ul>
        </li>
        <li class="treeview">
            <a href="#"><i class="fa fa-shopping-cart"></i> <span>Transaksi</span>
              <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
            </a>
            <ul class="treeview-menu">
            <li><a href='<?php echo e(url("trans/peminjaman")); ?>'>Peminjaman</a></li>
            li><a href='<?php echo e(url("trans/pengembalian")); ?>'>Pengembalian</a></li>
            
          </ul>
        </li>
        <li class="treeview">
      <a href="#"><i class="fa fa-book"></i> <span>Laporan</span>
        <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
      </a>
      <ul class="treeview-menu">
        <li><a href="<?php echo e(url('rpt/anggota')); ?>" target="blank">Laporan Anggota</a></li>
      </ul>
    </li>
    <li class="treeview">
      <a href="#"><i class="fa fa-user"></i> <span>Users</span>
        <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
      </a>
      <ul class="treeview-menu">
        <li><a href="<?php echo e(url('user/add')); ?>" target="blank">Add New</a></li>
        <li><a href="<?php echo e(url('user')); ?>">Data User</a></li>
      </ul>
    </li>  


       
      </ul>
     
      
      <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
  </aside>