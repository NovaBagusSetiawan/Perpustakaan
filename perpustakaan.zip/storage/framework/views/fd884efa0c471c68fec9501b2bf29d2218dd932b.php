<?php $__env->startSection('judul'); ?>
Form Kategori
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form id="frmKategori" class="form-horizontal" action="<?php echo e(url('kategori/save')); ?>" method="post" enctype="multipart/form-data">
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    <div class="row">
        <div class="fForm col-md-8">
            <div class="box">
                <!-- Bidodata Anggota -->
                <div class="box-header with-border">
                    <h3 class="box-title">Data Kategori</h3>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <label for="kategori" class="col-sm-2 control-label">kategori</label>
                        <div class="col-sm-10">
                            <input type="hidden" class="form-control" id="kd_kategori" name="kd_kategori" value="<?php echo e($kategori['kd_kategori']); ?>">
                            <input type="text" class="form-control" id="kategori" placeholder="Nama Kategori" name="kategori" value="<?php echo e($kategori['nama_kategori']); ?>">
                        </div>
                    </div>
                </div>
                <!-- /.box-body -->
                <div class="box-footer">
                    <button type="submit" class="btn btn-primary pull-right">SAVE</button>
                </div>                   
            </div>
        </div>       
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>