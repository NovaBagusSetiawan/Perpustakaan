<?php $__env->startSection('judul'); ?>
Daftar Rak
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form id="frmRak" class="form-horizontal" action="<?php echo e(url('rak/save')); ?>" method="post" enctype="multipart/form-data">
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    <div class="row">
        <div class="fForm col-md-8">
            <div class="box">
                <!-- Bidodata Anggota -->
                <div class="box-header with-border">
                    <h3 class="box-title">Data Rak</h3>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <label for="pengarang" class="col-sm-2 control-label">Rak</label>
                        <div class="col-sm-10">
                            <input type="hidden" class="form-control" id="kd_rak" name="kd_rak" value="<?php echo e($rak['kd_rak']); ?>">
                            <input type="text" class="form-control" id="rak" placeholder="Nama Rak" name="rak" value="<?php echo e($rak['nama_rak']); ?>">
                        </div>
                    </div>
                </div>
                <!-- /.box-body -->
                <div class="box-footer">
                    <button type="submit" class="btn btn-primary pull-right">SAVE</button>
                </div>                   
            </div>
        </div>       
    </div>
</form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>