<?php $__env->startSection('judul'); ?>
Data Koleksi Buku
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="box">
    <div class="box-header">
    <a href="<?php echo e(url('koleksi/add')); ?>"><button type="button" class="btn bg-green btn-flat margin">Add New</button></a>
    </div>
    <div class="box-body">
        <table id="data" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Kd</th>
                    <th>No Induk</th>
                    <th>Judul</th>
                    <th>Tanggal</th>
                    <th>Akses</th>
                    <th>Rak</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <!-- Menampilkan Data Anggota -->
                <?php $__currentLoopData = $koleksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsKoleksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($rsKoleksi->kd_koleksi); ?></td>
                    <td><?php echo e($rsKoleksi->no_induk_buku); ?></td>                    
                    <td><?php echo e($rsKoleksi->judul); ?></td>
                    <td><?php echo e($rsKoleksi->tgl_pengadaan); ?></td>
                    <td><?php echo e($rsKoleksi->akses); ?></td>
                    <td><?php echo e($rsKoleksi->nama_rak); ?></td>
                    <td><?php echo e(($rsKoleksi->status==0 ? "Tersedia" : ($rsKoleksi->status==1 ? "Dipinjam" : ($rsKoleksi->status==2 ? "Rusak" : "Hilang")))); ?></td>
                    <td>
                        <a href="<?php echo e(url('koleksi/edit',$rsKoleksi->kd_koleksi)); ?>"><button type="button" class="btn bg-yellow btn-flat"><i class="fa fa-pencil"></i></button></a>
                        <a href="<?php echo e(url('koleksi/delete',$rsKoleksi->kd_koleksi)); ?>"><button type="button" class="btn bg-red btn-flat"><i class="fa fa-trash"></i></button></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>